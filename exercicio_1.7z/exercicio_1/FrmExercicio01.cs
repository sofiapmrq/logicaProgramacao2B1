﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace exercicio_1
{
    public partial class FrmExercicio01 : Form
    {
        public FrmExercicio01()
        {
            InitializeComponent();
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
 
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float soma;


            soma = num1 + num3;
            MessageBox.Show("Soma = " + soma);
        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float media;

            media = (num1 + num2 + num3) / 3;
            MessageBox.Show("Media =" + media);
        }

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txtnum1.Text);
            float num2 = float.Parse(txtnum2.Text);
            float num3 = float.Parse(txtnum3.Text);
            float porc1, porc2, porc3;

            porc1 = num1 / (num1 + num2 + num3) * 100;
            porc2 = num2 / (num1 + num2 + num3) * 100;
            porc3 = num3 / (num1 + num2 + num3) * 100;
            MessageBox.Show("Porcentagem de num1 =" + porc1);
            MessageBox.Show("Porcentagem de num2 =" + porc2);
            MessageBox.Show("Porcentagem de num3 =" + porc3);
        }

       
    }
}


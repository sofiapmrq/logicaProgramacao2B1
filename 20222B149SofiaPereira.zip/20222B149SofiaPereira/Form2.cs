﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _20222B149SofiaPereira
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            float peso = float.Parse(txtPeso.Text);
        float altura = float.Parse(txtAltura.Text);
            float total= float.Parse(lbltotal.Text);

            lbltotal.Text = (peso / (altura * altura)).ToString();

            lbltotal.Text = "o IMC é:" + lbltotal;
        }
    }
}

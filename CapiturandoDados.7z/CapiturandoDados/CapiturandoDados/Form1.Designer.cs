﻿namespace CapiturandoDados
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.labelInteiro = new System.Windows.Forms.Label();
            this.labelTexto = new System.Windows.Forms.Label();
            this.labelDecimal = new System.Windows.Forms.Label();
            this.labelBoleano = new System.Windows.Forms.Label();
            this.textInteiro = new System.Windows.Forms.TextBox();
            this.textTexto = new System.Windows.Forms.TextBox();
            this.textDecimal = new System.Windows.Forms.TextBox();
            this.textBoleano = new System.Windows.Forms.TextBox();
            this.buttonLimpar = new System.Windows.Forms.Button();
            this.buttonEntrar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // labelInteiro
            // 
            this.labelInteiro.AutoSize = true;
            this.labelInteiro.Location = new System.Drawing.Point(31, 28);
            this.labelInteiro.Name = "labelInteiro";
            this.labelInteiro.Size = new System.Drawing.Size(36, 13);
            this.labelInteiro.TabIndex = 0;
            this.labelInteiro.Text = "Inteiro";
//            this.labelInteiro.Click += new System.EventHandler(this.labelInteiro_Click);
            // 
            // labelTexto
            // 
            this.labelTexto.AutoSize = true;
            this.labelTexto.Location = new System.Drawing.Point(34, 109);
            this.labelTexto.Name = "labelTexto";
            this.labelTexto.Size = new System.Drawing.Size(34, 13);
            this.labelTexto.TabIndex = 1;
            this.labelTexto.Text = "Texto";
  //          this.labelTexto.Click += new System.EventHandler(this.labelTexto_Click);
            // 
            // labelDecimal
            // 
            this.labelDecimal.AutoSize = true;
            this.labelDecimal.Location = new System.Drawing.Point(34, 197);
            this.labelDecimal.Name = "labelDecimal";
            this.labelDecimal.Size = new System.Drawing.Size(45, 13);
            this.labelDecimal.TabIndex = 2;
            this.labelDecimal.Text = "Decimal";
            this.labelDecimal.Click += new System.EventHandler(this.labelDecimal_Click);
            // 
            // labelBoleano
            // 
            this.labelBoleano.AutoSize = true;
            this.labelBoleano.Location = new System.Drawing.Point(34, 290);
            this.labelBoleano.Name = "labelBoleano";
            this.labelBoleano.Size = new System.Drawing.Size(46, 13);
            this.labelBoleano.TabIndex = 3;
            this.labelBoleano.Text = "Boleano";
            this.labelBoleano.Click += new System.EventHandler(this.labelBoleano_Click);
            // 
            // textInteiro
            // 
            this.textInteiro.Location = new System.Drawing.Point(34, 44);
            this.textInteiro.Name = "textInteiro";
            this.textInteiro.Size = new System.Drawing.Size(178, 20);
            this.textInteiro.TabIndex = 4;
 //           this.textInteiro.TextChanged += new System.EventHandler(this.textInteiro_TextChanged);
            // 
            // textTexto
            // 
            this.textTexto.Location = new System.Drawing.Point(37, 125);
            this.textTexto.Name = "textTexto";
            this.textTexto.Size = new System.Drawing.Size(178, 20);
            this.textTexto.TabIndex = 5;
            this.textTexto.TextChanged += new System.EventHandler(this.textTexto_TextChanged);
            // 
            // textDecimal
            // 
            this.textDecimal.Location = new System.Drawing.Point(37, 213);
            this.textDecimal.Name = "textDecimal";
            this.textDecimal.Size = new System.Drawing.Size(178, 20);
            this.textDecimal.TabIndex = 6;
            this.textDecimal.TextChanged += new System.EventHandler(this.textDecimal_TextChanged);
            // 
            // textBoleano
            // 
            this.textBoleano.Location = new System.Drawing.Point(37, 306);
            this.textBoleano.Name = "textBoleano";
            this.textBoleano.Size = new System.Drawing.Size(178, 20);
            this.textBoleano.TabIndex = 7;
            this.textBoleano.TextChanged += new System.EventHandler(this.textBoleano_TextChanged);
            // 
            // buttonLimpar
            // 
            this.buttonLimpar.Location = new System.Drawing.Point(383, 362);
            this.buttonLimpar.Name = "buttonLimpar";
            this.buttonLimpar.Size = new System.Drawing.Size(145, 36);
            this.buttonLimpar.TabIndex = 8;
            this.buttonLimpar.Text = "Limpar";
            this.buttonLimpar.UseVisualStyleBackColor = true;
            this.buttonLimpar.Click += new System.EventHandler(this.buttonLimpar_Click);
            // 
            // buttonEntrar
            // 
            this.buttonEntrar.Location = new System.Drawing.Point(604, 362);
            this.buttonEntrar.Name = "buttonEntrar";
            this.buttonEntrar.Size = new System.Drawing.Size(137, 36);
            this.buttonEntrar.TabIndex = 9;
            this.buttonEntrar.Text = "Entrar";
            this.buttonEntrar.UseVisualStyleBackColor = true;
            this.buttonEntrar.Click += new System.EventHandler(this.buttonEntrar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonEntrar);
            this.Controls.Add(this.buttonLimpar);
            this.Controls.Add(this.textBoleano);
            this.Controls.Add(this.textDecimal);
            this.Controls.Add(this.textTexto);
            this.Controls.Add(this.textInteiro);
            this.Controls.Add(this.labelBoleano);
            this.Controls.Add(this.labelDecimal);
            this.Controls.Add(this.labelTexto);
            this.Controls.Add(this.labelInteiro);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Capiturando dados na tela";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelInteiro;
        private System.Windows.Forms.Label labelTexto;
        private System.Windows.Forms.Label labelDecimal;
        private System.Windows.Forms.Label labelBoleano;
        private System.Windows.Forms.TextBox textInteiro;
        private System.Windows.Forms.TextBox textTexto;
        private System.Windows.Forms.TextBox textDecimal;
        private System.Windows.Forms.TextBox textBoleano;
        private System.Windows.Forms.Button buttonLimpar;
        private System.Windows.Forms.Button buttonEntrar;
    }
}


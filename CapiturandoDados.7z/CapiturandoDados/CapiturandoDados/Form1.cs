﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapiturandoDados
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Clicou no botão!");
        }

        private void FrmDados_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Abriu formulário!");
        }

        private void txtInteiro_TextChanged(object sender, EventArgs e)
        {
            MessageBox.Show("Alterou Texto!");
        }

        private void textTexto_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelDecimal_Click(object sender, EventArgs e)
        {

        }

        private void textDecimal_TextChanged(object sender, EventArgs e)
        {

        }

        private void labelBoleano_Click(object sender, EventArgs e)
        {

        }

        private void textBoleano_TextChanged(object sender, EventArgs e)
        {

        }

        private void buttonLimpar_Click(object sender, EventArgs e)
        {

        }

        private void buttonEntrar_Click(object sender, EventArgs e)
        {

        }
    }
}
